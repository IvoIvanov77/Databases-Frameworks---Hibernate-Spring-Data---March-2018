package app.retake.domain.models;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Set;

@Entity
@Table(name = "vets")
public class Vet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Length(min = 3, max = 40)
    private String name;

    @Length(min = 3, max = 50)
    private String profession;

    @Min(22)
    @Max(65)
    private Integer age;

    @NotNull
    @Pattern(regexp = "^(\\+359|0)\\d{9}$")
    private String phoneNumber;

    @OneToMany(mappedBy = "vet")
    private Set<Procedure> procedures;



}
