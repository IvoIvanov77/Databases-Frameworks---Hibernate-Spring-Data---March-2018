package app.retake.io;

import app.retake.io.api.FileIO;

import java.io.*;

public class FIleIOImpl implements FileIO {

    @Override
    public String read(String file) throws IOException {
        return null;
    }

    @Override
    public void write(String fileContent, String file) throws IOException {

    }
}
