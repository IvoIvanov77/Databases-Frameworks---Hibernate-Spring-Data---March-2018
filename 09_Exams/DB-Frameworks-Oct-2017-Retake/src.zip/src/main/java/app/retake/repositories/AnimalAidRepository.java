package app.retake.repositories;

import org.springframework.stereotype.Repository;

public interface AnimalAidRepository {
}
