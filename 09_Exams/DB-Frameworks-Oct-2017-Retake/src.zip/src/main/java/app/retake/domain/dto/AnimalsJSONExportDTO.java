package app.retake.domain.dto;

import java.io.Serializable;

public class AnimalsJSONExportDTO implements Serializable {
}
