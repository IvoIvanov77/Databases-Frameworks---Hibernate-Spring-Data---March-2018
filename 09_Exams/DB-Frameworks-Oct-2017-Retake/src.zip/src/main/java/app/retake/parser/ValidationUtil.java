package app.retake.parser;

public final class ValidationUtil {
    public static <T> boolean isValid(T t) {
        return false;
    }
}
