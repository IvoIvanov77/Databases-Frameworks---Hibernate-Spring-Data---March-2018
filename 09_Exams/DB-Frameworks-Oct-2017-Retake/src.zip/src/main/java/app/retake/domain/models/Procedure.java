package app.retake.domain.models;

import javax.persistence.*;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "procedures")
public class Procedure {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private Date datePerformed;

    @ManyToOne(targetEntity = Animal.class)
    private Animal animal;

    @ManyToOne(targetEntity = Vet.class)
    private Vet vet;

    @ManyToMany(targetEntity = AnimalAid.class)
    private Set<AnimalAid> services;
}
