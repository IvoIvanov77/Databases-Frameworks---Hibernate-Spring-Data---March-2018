package app.retake.controllers;

public class VetController {

    public String importDataFromXML(String xmlContent){
        return null;
    }
}
