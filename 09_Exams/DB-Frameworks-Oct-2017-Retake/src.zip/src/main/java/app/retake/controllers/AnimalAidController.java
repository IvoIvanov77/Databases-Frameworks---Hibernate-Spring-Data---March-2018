package app.retake.controllers;

import java.io.IOException;

public class AnimalAidController {

    public String importDataFromJSON(String jsonContent) throws IOException {
        return null;
    }
}
