package app.retake.domain.models;

import org.hibernate.validator.constraints.Length;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "passports")
public class Passport implements Serializable {

    @Id
    @Pattern(regexp = "^.{7}\\d{3}$")
    private String serialNumber;

    @OneToOne(mappedBy = "passport")
    private Animal animal;

    @Length(min = 3, max = 30)
    private String ownerName;

    @Pattern(regexp = "^(\\+359|0)\\d{9}$")
    private String ownerPhoneNumber;

    private Date registeredOn;


}
