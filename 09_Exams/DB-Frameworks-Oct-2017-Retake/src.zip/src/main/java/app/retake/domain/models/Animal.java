package app.retake.domain.models;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Entity
@Table(name = "animals")
public class Animal {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull
    @Length(min = 3, max = 20)
    private String name;

    @NotNull
    @Length(min = 3, max = 20)
    private String type;

    @Min(1)
    private Integer age;

    @OneToOne(targetEntity = Passport.class)
    @JoinColumn(
            name="passport_serial_number", unique=true, nullable=false, updatable=false)
    private Passport passport;

    @OneToMany(mappedBy = "animal")
    private Set<Procedure> procedures;



}
